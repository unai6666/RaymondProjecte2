import React, { useState, useEffect } from 'react';
import { IonApp, IonRouterOutlet } from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';
import { Redirect, Route } from 'react-router-dom';

// Importar páginas
import Home from './pages/Home';
import Search from './pages/Search';
import MovieDetails from './pages/MovieDetails';
import Favorites from './pages/Favorites';
import Login from './pages/Login';

// Importar servicios
import { subscribeToAuthChanges } from './services/auth';
import { syncFavoritesToFirebase } from './services/storage';
import app, { auth } from './services/firebase';

// Importar estilos de Ionic
import '@ionic/react/css/core.css';
import '@ionic/react/css/normalize.css';
import '@ionic/react/css/structure.css';
import '@ionic/react/css/typography.css';
import '@ionic/react/css/padding.css';
import '@ionic/react/css/float-elements.css';
import '@ionic/react/css/text-alignment.css';
import '@ionic/react/css/text-transformation.css';
import '@ionic/react/css/flex-utils.css';
import '@ionic/react/css/display.css';
import './theme.css';

const App = () => {
  const [user, setUser] = useState(null);
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    // Suscripción a cambios de autenticación
    const unsubscribe = subscribeToAuthChanges((user) => {
      setUser(user);
      setIsAuthReady(true);
      
      if (user) {
        // Inicializar favoritos cuando el usuario ha iniciado sesión
        syncFavoritesToFirebase();
      }
    });
    
    // Limpiar la suscripción cuando se desmonta el componente
    return () => unsubscribe();
  }, []);

  // Si la autenticación no está lista, mostramos una pantalla de carga o nada
  if (!isAuthReady) {
    return <IonApp></IonApp>;
  }

  return (
    <IonApp>
      <IonReactRouter>
        <IonRouterOutlet animated>
          <Route path="/login" component={Login} exact />
          
          {/* Rutas protegidas que requieren autenticación */}
          <Route 
            path="/home" 
            render={() => user ? <Home /> : <Redirect to="/login" />} 
            exact 
          />
          <Route 
            path="/search" 
            render={() => user ? <Search /> : <Redirect to="/login" />} 
            exact 
          />
          <Route 
            path="/details/:id" 
            render={(props) => user ? <MovieDetails {...props} /> : <Redirect to="/login" />} 
            exact 
          />
          <Route 
            path="/favorites" 
            render={() => user ? <Favorites /> : <Redirect to="/login" />} 
            exact 
          />
          
          <Route exact path="/">
            <Redirect to={user ? "/home" : "/login"} />
          </Route>
        </IonRouterOutlet>
      </IonReactRouter>
    </IonApp>
  );
};

export default App;