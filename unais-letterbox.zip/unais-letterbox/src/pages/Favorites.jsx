import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { 
  IonContent, 
  IonHeader, 
  IonPage, 
  IonTitle, 
  IonToolbar,
  IonList,
  IonItem,
  IonThumbnail,
  IonLabel,
  IonButton,
  IonIcon,
  IonAlert,
  IonFooter,
  IonTabBar,
  IonTabButton,
  IonButtons,
  IonBackButton,
  IonItemSliding,
  IonItemOptions,
  IonItemOption,
  IonBadge,
  IonModal,
  IonTextarea,
  IonRange,
  IonToast,
  IonLoading,
  IonCard,
  IonCardContent
} from '@ionic/react';
import { 
  searchOutline, 
  heartOutline, 
  homeOutline, 
  trashOutline, 
  createOutline, 
  starOutline,
  filmOutline,
  tvOutline
} from 'ionicons/icons';
import { 
  removeFromFavorites, 
  updateFavorite,
  subscribeFavoritesFromFirebase
} from '../services/storage';
import { auth } from '../services/firebase';

const Favorites = () => {
  const history = useHistory();
  const [myFilms, setMyFilms] = useState({});
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [userRating, setUserRating] = useState(0);
  const [userComment, setUserComment] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setMyFilms({});
    if (auth.currentUser) {
      const unsubscribe = subscribeFavoritesFromFirebase((data) => {
        setMyFilms(data || {});
        setLoading(false);
      });
      
      return () => unsubscribe();
    } else {
      setLoading(false);
    }
  }, [auth.currentUser]);

  const handleDelete = (id) => {
    setSelectedItem(id);
    setShowDeleteAlert(true);
  };

  const confirmDelete = async () => {
    if (selectedItem) {
      try {
        await removeFromFavorites(selectedItem);
        setToastMessage('Element eliminat de favorits');
        setShowToast(true);
      } catch (error) {
        setToastMessage('Error en eliminar de favorits');
        setShowToast(true);
        console.error(error);
      }
    }
    setShowDeleteAlert(false);
    setSelectedItem(null);
  };

  const handleEdit = (item) => {
    setSelectedItem(item);
    setUserRating(item.userRating || 0);
    setUserComment(item.userComment || '');
    setShowEditModal(true);
  };

  const saveEdit = async () => {
    if (selectedItem) {
      try {
        await updateFavorite(selectedItem.imdbID, {
          userRating,
          userComment
        });
        
        setToastMessage('Valoració guardada');
        setShowToast(true);
      } catch (error) {
        setToastMessage('Error en guardar la valoració');
        setShowToast(true);
        console.error(error);
      }
    }
    setShowEditModal(false);
  };

  const navigateToDetails = (id) => {
    history.push(`/details/${id}`);
  };

  const myFilmsKeys = Object.keys(myFilms);

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="primary">
          <IonButtons slot="start">
            <IonBackButton defaultHref="/home" />
          </IonButtons>
          <IonTitle>Els meus favorits</IonTitle>
        </IonToolbar>
      </IonHeader>
      
      <IonContent className="ion-padding">
        {loading ? (
          <IonLoading isOpen={true} message={'Carregant favorits...'} />
        ) : myFilmsKeys.length > 0 ? (
          <IonList>
            {myFilmsKeys.map((key) => (
              <IonItemSliding key={key}>
                <IonItem 
                  button 
                  onClick={() => navigateToDetails(myFilms[key].imdbID)}
                  style={{ 
                    '--background': 'rgba(255, 255, 255, 0.7)',
                    '--background-activated': 'rgba(90, 103, 216, 0.05)',
                    borderRadius: '8px',
                    margin: '8px 0',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.08)'
                  }}
                  className="ion-margin-bottom"
                >
                  <IonThumbnail slot="start" style={{ borderRadius: '6px', overflow: 'hidden' }}>
                    {myFilms[key].Poster !== 'N/A' ? (
                      <img src={myFilms[key].Poster} alt={myFilms[key].Title} />
                    ) : (
                      <div 
                        style={{ 
                          width: '100%', 
                          height: '100%', 
                          backgroundColor: '#e8eaed', 
                          display: 'flex', 
                          justifyContent: 'center', 
                          alignItems: 'center',
                          color: '#666666',
                          fontSize: '20px'
                        }}
                      >
                        🎬
                      </div>
                    )}
                  </IonThumbnail>
                  <IonLabel>
                    <h2 style={{ fontWeight: 'bold', fontSize: '16px' }}>{myFilms[key].Title}</h2>
                    <p style={{ display: 'flex', alignItems: 'center', gap: '5px', marginTop: '4px' }}>
                      {myFilms[key].Year} • 
                      <span 
                        className={`media-type-label ${myFilms[key].Type === 'movie' ? 'movie-label' : 'series-label'}`}
                        style={{ fontSize: '10px', padding: '2px 6px' }}
                      >
                        {myFilms[key].Type === 'movie' ? 'Pel·lícula' : 'Sèrie'}
                      </span>
                    </p>
                    {myFilms[key].userRating > 0 && (
                      <div style={{ marginTop: '8px' }}>
                        <IonBadge color="warning" style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '6px' }}>
                          <IonIcon icon={starOutline} style={{ fontSize: '14px' }} /> 
                          <span style={{ fontWeight: 'bold' }}>{myFilms[key].userRating}/10</span>
                        </IonBadge>
                      </div>
                    )}
                    {myFilms[key].userComment && (
                      <p style={{ 
                        marginTop: '6px', 
                        fontSize: '12px', 
                        color: '#666', 
                        whiteSpace: 'nowrap', 
                        overflow: 'hidden', 
                        textOverflow: 'ellipsis',
                        maxWidth: '95%'
                      }}>
                        "{myFilms[key].userComment}"
                      </p>
                    )}
                  </IonLabel>
                </IonItem>
                
                <IonItemOptions side="end">
                  <IonItemOption color="warning" onClick={() => handleEdit(myFilms[key])}>
                    <IonIcon slot="icon-only" icon={createOutline} />
                  </IonItemOption>
                  <IonItemOption color="danger" onClick={() => handleDelete(myFilms[key].imdbID)}>
                    <IonIcon slot="icon-only" icon={trashOutline} />
                  </IonItemOption>
                </IonItemOptions>
              </IonItemSliding>
            ))}
          </IonList>
        ) : (
          <IonCard>
            <IonCardContent className="ion-text-center">
              <h2>No tens cap pel·lícula a la col·lecció</h2>
              <p>Cerca pel·lícules i sèries i afegeix-les a la teva col·lecció</p>
              <IonButton routerLink="/search" expand="block" className="ion-margin-top">
                Cercar ara
              </IonButton>
            </IonCardContent>
          </IonCard>
        )}
      </IonContent>
      
      {/* Modal para editar valoración */}
      <IonModal isOpen={showEditModal} onDidDismiss={() => setShowEditModal(false)}>
        <IonHeader>
          <IonToolbar color="primary">
            <IonTitle>Valoració</IonTitle>
            <IonButtons slot="end">
              <IonButton onClick={() => setShowEditModal(false)}>Cancel·lar</IonButton>
            </IonButtons>
          </IonToolbar>
        </IonHeader>
        
        <IonContent className="ion-padding">
          {selectedItem && (
            <>
              <div style={{ marginBottom: '20px', textAlign: 'center' }}>
                {selectedItem.Poster !== 'N/A' ? (
                  <img 
                    src={selectedItem.Poster} 
                    alt={selectedItem.Title}
                    style={{ 
                      maxHeight: '200px', 
                      borderRadius: '10px', 
                      boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                      margin: '0 auto',
                      display: 'block'
                    }}
                  />
                ) : (
                  <div 
                    style={{ 
                      width: '150px', 
                      height: '200px', 
                      background: 'linear-gradient(135deg, #f5f7fa, #e8eaed)', 
                      display: 'flex', 
                      justifyContent: 'center', 
                      alignItems: 'center',
                      color: '#666666',
                      borderRadius: '10px',
                      margin: '0 auto'
                    }}
                  >
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '42px', marginBottom: '10px' }}>🎬</div>
                      <div>Sense imatge</div>
                    </div>
                  </div>
                )}
              </div>
              
              <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>{selectedItem.Title}</h2>
              
              <div className="rating-container ion-padding">
                <IonLabel style={{ fontWeight: 'bold', fontSize: '18px', display: 'block', marginBottom: '10px' }}>
                  La teva valoració
                </IonLabel>
                <div className="rating-stars">
                  <IonRange
                    min={0}
                    max={10}
                    step={0.5}
                    value={userRating}
                    onIonChange={(e) => setUserRating(e.detail.value)}
                    style={{ padding: '0 10px' }}
                  >
                    <IonIcon slot="start" icon={starOutline} style={{ color: '#f59e0b' }} />
                    <IonIcon slot="end" icon={starOutline} style={{ color: '#f59e0b' }} />
                  </IonRange>
                  <div className="ion-text-center">
                    <strong style={{ fontSize: '24px', color: '#f59e0b' }}>{userRating}</strong>
                    <span style={{ fontSize: '18px', color: '#666' }}>/10</span>
                  </div>
                </div>
              </div>
              
              <div className="comment-container ion-padding-top">
                <IonLabel style={{ fontWeight: 'bold', fontSize: '18px', display: 'block', marginBottom: '10px' }}>
                  Els teus comentaris
                </IonLabel>
                <IonTextarea
                  value={userComment}
                  onIonChange={(e) => setUserComment(e.detail.value)}
                  placeholder="Escriu els teus comentaris sobre aquesta pel·lícula o sèrie..."
                  rows={5}
                  style={{ 
                    border: '1px solid rgba(0,0,0,0.1)', 
                    borderRadius: '10px', 
                    '--padding-start': '10px',
                    '--padding-end': '10px',
                    '--padding-top': '10px',
                    '--padding-bottom': '10px',
                    margin: '10px 0'
                  }}
                />
              </div>
              
              <IonButton 
                expand="block" 
                onClick={saveEdit} 
                color="secondary"
                className="ion-margin-top"
                style={{ 
                  '--border-radius': '10px',
                  height: '48px',
                  fontSize: '16px',
                  margin: '25px 0 15px'
                }}
              >
                Guardar valoració
              </IonButton>
            </>
          )}
        </IonContent>
      </IonModal>
      
      {/* Alerta per confirmar eliminació */}
      <IonAlert
        isOpen={showDeleteAlert}
        onDidDismiss={() => setShowDeleteAlert(false)}
        header="Confirmar eliminació"
        message="Estàs segur que vols eliminar aquest element dels teus favorits?"
        buttons={[
          {
            text: 'Cancel·lar',
            role: 'cancel',
            handler: () => {
              setShowDeleteAlert(false);
              setSelectedItem(null);
            },
          },
          {
            text: 'Eliminar',
            handler: confirmDelete,
          },
        ]}
      />
      
      <IonToast
        isOpen={showToast}
        onDidDismiss={() => setShowToast(false)}
        message={toastMessage}
        duration={2000}
        position="bottom"
      />
      
      <IonFooter>
        <IonTabBar slot="bottom">
          <IonTabButton tab="home" routerLink="/home">
            <IonIcon icon={homeOutline} />
            <IonLabel>Inici</IonLabel>
          </IonTabButton>
          
          <IonTabButton tab="search" routerLink="/search">
            <IonIcon icon={searchOutline} />
            <IonLabel>Cercar</IonLabel>
          </IonTabButton>
          
          <IonTabButton tab="favorites" routerLink="/favorites" selected>
            <IonIcon icon={heartOutline} />
            <IonLabel>Els meus</IonLabel>
          </IonTabButton>
        </IonTabBar>
      </IonFooter>
    </IonPage>
  );
};

export default Favorites;