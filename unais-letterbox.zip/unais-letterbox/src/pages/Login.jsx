import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { 
  IonContent, 
  IonHeader, 
  IonPage, 
  IonTitle, 
  IonToolbar,
  IonItem,
  IonLabel,
  IonInput,
  IonButton,
  IonLoading,
  IonToast,
  IonGrid,
  IonRow,
  IonCol,
  IonText
} from '@ionic/react';
import { loginUser, registerUser } from '../services/auth';

const Login = () => {
  const history = useHistory();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showLoading, setShowLoading] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [isLogin, setIsLogin] = useState(true); // true = login, false = register

  const handleAuth = async () => {
    setShowLoading(true);
    
    try {
      let result;
      
      if (isLogin) {
        result = await loginUser(email, password);
      } else {
        result = await registerUser(email, password);
      }
      
      if (result.error) {
        setToastMessage(result.error);
        setShowToast(true);
      } else {
        // Autenticació correcta, redirigir a l'inici
        history.push('/home');
      }
    } catch (error) {
      setToastMessage(error.message);
      setShowToast(true);
    } finally {
      setShowLoading(false);
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle>{isLogin ? 'Iniciar sessió' : 'Crear compte'}</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonGrid>
          <IonRow className="ion-justify-content-center">
            <IonCol size="12" sizeMd="8" sizeLg="6">
              <div className="ion-text-center ion-margin-bottom">
                <h2>{isLogin ? 'Accedeix al teu compte' : 'Crea un compte nou'}</h2>
                <p>Accedeix a les teves pel·lícules i sèries preferides des de qualsevol dispositiu</p>
              </div>
              
              <IonItem>
                <IonLabel position="floating">Correu electrònic</IonLabel>
                <IonInput
                  type="email"
                  value={email}
                  onIonChange={e => setEmail(e.detail.value)}
                  required
                />
              </IonItem>
              
              <IonItem className="ion-margin-bottom">
                <IonLabel position="floating">Contrasenya</IonLabel>
                <IonInput
                  type="password"
                  value={password}
                  onIonChange={e => setPassword(e.detail.value)}
                  required
                />
              </IonItem>
              
              {isLogin && (
                <IonButton 
                  expand="block" 
                  onClick={() => console.log('Forgot password')}
                  fill="clear"
                  size="small"
                  className="ion-margin-bottom"
                >
                  He oblidat la meva contrasenya
                </IonButton>
              )}
              
              <IonButton
                expand="block"
                onClick={handleAuth}
                className="ion-margin-bottom"
              >
                {isLogin ? 'Iniciar sessió' : 'Crear compte'}
              </IonButton>
              
              <div className="ion-text-center">
                <IonText>
                  {isLogin ? "No tens compte? " : "Ja tens un compte? "}
                  <IonButton
                    fill="clear"
                    onClick={() => setIsLogin(!isLogin)}
                  >
                    {isLogin ? 'Crea un compte' : 'Inicia sessió'}
                  </IonButton>
                </IonText>
              </div>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonContent>
      
      <IonLoading
        isOpen={showLoading}
        message={'Processant...'}
      />
      
      <IonToast
        isOpen={showToast}
        onDidDismiss={() => setShowToast(false)}
        message={toastMessage}
        duration={2000}
        position="bottom"
      />
    </IonPage>
  );
};

export default Login;