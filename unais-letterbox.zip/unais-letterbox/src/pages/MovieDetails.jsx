import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { 
  IonContent, 
  IonHeader, 
  IonPage, 
  IonTitle, 
  IonToolbar,
  IonButtons,
  IonBackButton,
  IonCard,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonLoading,
  IonToast,
  IonFooter,
  IonTabBar,
  IonTabButton,
  IonLabel,
  IonChip,
  IonList,
  IonItem,
  IonGrid,
  IonRow,
  IonCol,
  IonBadge,
  IonModal,
  IonTextarea,
  IonRange
} from '@ionic/react';
import { 
  heartOutline, 
  heartSharp, 
  homeOutline, 
  searchOutline, 
  starOutline, 
  timeOutline, 
  filmOutline, 
  tvOutline,
  createOutline
} from 'ionicons/icons';
import { getMediaDetails } from '../services/api';
import { addToFavorites, removeFromFavorites, updateFavorite, subscribeFavoritesFromFirebase } from '../services/storage';
import { auth } from '../services/firebase';

const MovieDetails = () => {
  const { id } = useParams();
  const [media, setMedia] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isFavorite, setIsFavorite] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [myFilms, setMyFilms] = useState({});
  
  // Añadido para gestionar reseñas y comentarios
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [userRating, setUserRating] = useState(0);
  const [userComment, setUserComment] = useState('');
  
  // Cargar favoritos de Firebase
  useEffect(() => {
    if (auth.currentUser) {
      const unsubscribe = subscribeFavoritesFromFirebase((data) => {
        setMyFilms(data || {});
        checkFavoriteStatus(data);
      });
      
      return () => unsubscribe();
    }
  }, [auth.currentUser, id]);
  
  // Función para verificar el estado de favorito
  const checkFavoriteStatus = useCallback((favoritesData) => {
    const favorites = favoritesData || myFilms;
    const isAlreadyFavorite = Object.keys(favorites).includes(id);
    setIsFavorite(isAlreadyFavorite);
    
    if (isAlreadyFavorite && favorites[id]) {
      setUserRating(favorites[id].userRating || 0);
      setUserComment(favorites[id].userComment || '');
    } else {
      setUserRating(0);
      setUserComment('');
    }
  }, [id, myFilms]);
  
  useEffect(() => {
    const fetchMediaDetails = async () => {
      try {
        const details = await getMediaDetails(id);
        if (details.Response === 'True') {
          setMedia(details);
        } else {
          setError(details.Error || 'No s\'ha pogut carregar la informació');
        }
      } catch (err) {
        setError('Error al carregar els detalls');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchMediaDetails();
  }, [id]);
  
  const handleFavoriteToggle = async () => {
    try {
      if (isFavorite) {
        await removeFromFavorites(id);
        setToastMessage('Eliminat de favorits');
        setIsFavorite(false);
        setUserRating(0);
        setUserComment('');
      } else {
        if (media) {
          await addToFavorites(media);
          setToastMessage('Afegit a favorits');
          setIsFavorite(true);
          
          // Si se añade a favoritos, mostramos el modal para valorar
          setShowReviewModal(true);
        }
      }
      
      setShowToast(true);
    } catch (error) {
      setToastMessage('Error en gestionar favorits');
      setShowToast(true);
      console.error(error);
    }
  };
  
  const handleSaveReview = async () => {
    try {
      await updateFavorite(id, {
        userRating,
        userComment
      });
      
      setShowReviewModal(false);
      setToastMessage('Valoració guardada');
      setShowToast(true);
    } catch (error) {
      setToastMessage('Error en guardar la valoració');
      setShowToast(true);
      console.error(error);
    }
  };
  
  const openReviewModal = () => {
    if (isFavorite) {
      setShowReviewModal(true);
    } else {
      setToastMessage('Afegeix primer a favorits per valorar');
      setShowToast(true);
    }
  };
  
  if (loading) {
    return (
      <IonPage>
        <IonLoading isOpen={true} message={'Carregant detalls...'} />
      </IonPage>
    );
  }
  
  if (error) {
    return (
      <IonPage>
        <IonHeader>
          <IonToolbar color="primary">
            <IonButtons slot="start">
              <IonBackButton defaultHref="/search" />
            </IonButtons>
            <IonTitle>Error</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent className="ion-padding ion-text-center">
          <h2>Error al carregar els detalls</h2>
          <p>{error}</p>
          <IonButton routerLink="/search">Tornar a la cerca</IonButton>
        </IonContent>
      </IonPage>
    );
  }

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="primary">
          <IonButtons slot="start">
            <IonBackButton defaultHref="/search" />
          </IonButtons>
          <IonTitle>{media?.Type === 'movie' ? 'Pel·lícula' : 'Sèrie'}</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={handleFavoriteToggle}>
              <IonIcon slot="icon-only" icon={isFavorite ? heartSharp : heartOutline} />
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      
      <IonContent className="ion-padding">
        {media && (
          <>
            <IonCard>
              <div className="poster-container">
                {media.Poster !== 'N/A' ? (
                  <img 
                    src={media.Poster} 
                    alt={media.Title}
                    style={{ width: '100%', maxHeight: '300px', objectFit: 'cover' }}
                  />
                ) : (
                  <div 
                    style={{ 
                      width: '100%', 
                      height: '300px', 
                      backgroundColor: '#cccccc', 
                      display: 'flex', 
                      justifyContent: 'center', 
                      alignItems: 'center',
                      color: '#666666'
                    }}
                  >
                    Sense imatge
                  </div>
                )}
              </div>
              
              <IonCardHeader>
                <IonCardSubtitle>
                  {media.Year} · {media.Rated} · {media.Runtime}
                </IonCardSubtitle>
                <IonCardTitle>{media.Title}</IonCardTitle>
              </IonCardHeader>
              
              <IonCardContent>
                <IonGrid>
                  <IonRow>
                    <IonCol size="auto">
                      <IonChip color={media.Type === 'movie' ? 'movie' : 'series'}>
                        <IonIcon icon={media.Type === 'movie' ? filmOutline : tvOutline} />
                        <IonLabel>{media.Type === 'movie' ? 'Pel·lícula' : 'Sèrie'}</IonLabel>
                      </IonChip>
                    </IonCol>
                    
                    {media.imdbRating !== 'N/A' && (
                      <IonCol size="auto">
                        <IonChip color="warning">
                          <IonIcon icon={starOutline} />
                          <IonLabel>{media.imdbRating}/10</IonLabel>
                        </IonChip>
                      </IonCol>
                    )}
                    
                    {media.Runtime !== 'N/A' && (
                      <IonCol size="auto">
                        <IonChip>
                          <IonIcon icon={timeOutline} />
                          <IonLabel>{media.Runtime}</IonLabel>
                        </IonChip>
                      </IonCol>
                    )}
                  </IonRow>
                </IonGrid>
                
                {/* Mostrar valoración y comentario personal si existen */}
                {isFavorite && (userRating > 0 || userComment) && (
                  <div 
                    style={{ 
                      backgroundColor: 'rgba(90, 103, 216, 0.05)', 
                      padding: '10px 15px', 
                      borderRadius: '10px',
                      margin: '15px 0'
                    }}
                  >
                    <h3 style={{ fontWeight: 'bold', marginBottom: '8px' }}>La teva valoració</h3>
                    
                    {userRating > 0 && (
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
                        <IonIcon icon={starOutline} style={{ color: '#f59e0b', marginRight: '5px' }} />
                        <span style={{ fontWeight: 'bold', color: '#f59e0b' }}>{userRating}/10</span>
                      </div>
                    )}
                    
                    {userComment && (
                      <div>
                        <p style={{ fontStyle: 'italic', margin: '5px 0' }}>"{userComment}"</p>
                      </div>
                    )}
                    
                    <IonButton 
                      fill="clear" 
                      size="small" 
                      onClick={openReviewModal}
                      style={{ margin: '5px 0 0' }}
                    >
                      <IonIcon slot="start" icon={createOutline} />
                      Editar valoració
                    </IonButton>
                  </div>
                )}
                
                <p className="ion-padding-top">{media.Plot}</p>
                
                <IonList lines="none">
                  {media.Director !== 'N/A' && (
                    <IonItem>
                      <IonLabel>
                        <h2>Director</h2>
                        <p>{media.Director}</p>
                      </IonLabel>
                    </IonItem>
                  )}
                  
                  {media.Writer !== 'N/A' && (
                    <IonItem>
                      <IonLabel>
                        <h2>Guionista</h2>
                        <p>{media.Writer}</p>
                      </IonLabel>
                    </IonItem>
                  )}
                  
                  {media.Actors !== 'N/A' && (
                    <IonItem>
                      <IonLabel>
                        <h2>Repartiment</h2>
                        <p>{media.Actors}</p>
                      </IonLabel>
                    </IonItem>
                  )}
                </IonList>
                
                <div className="ion-padding-top">
                  {media.Genre && media.Genre.split(', ').map((genre, index) => (
                    <IonBadge key={index} color="medium" className="ion-margin-end">
                      {genre}
                    </IonBadge>
                  ))}
                </div>
              </IonCardContent>
            </IonCard>
            
            <div style={{ display: 'flex', gap: '10px', marginTop: '15px' }}>
              <IonButton 
                expand="block" 
                onClick={handleFavoriteToggle} 
                color={isFavorite ? "danger" : "secondary"}
                style={{ 
                  borderRadius: '10px',
                  height: '48px',
                  fontSize: '16px',
                  fontWeight: 'bold',
                  flex: '1'
                }}
              >
                <IonIcon slot="start" icon={isFavorite ? heartSharp : heartOutline} />
                {isFavorite ? 'Eliminar' : 'Afegir'}
              </IonButton>
              
              {isFavorite && (
                <IonButton 
                  expand="block" 
                  onClick={openReviewModal} 
                  color="primary"
                  style={{ 
                    borderRadius: '10px',
                    height: '48px',
                    fontSize: '16px',
                    fontWeight: 'bold',
                    flex: '1'
                  }}
                >
                  <IonIcon slot="start" icon={createOutline} />
                  Valorar
                </IonButton>
              )}
            </div>
          </>
        )}
      </IonContent>
      
      {/* Modal para valorar y comentar */}
      <IonModal isOpen={showReviewModal} onDidDismiss={() => setShowReviewModal(false)}>
        <IonHeader>
          <IonToolbar color="primary">
            <IonTitle>La teva valoració</IonTitle>
            <IonButtons slot="end">
              <IonButton onClick={() => setShowReviewModal(false)}>Cancel·lar</IonButton>
            </IonButtons>
          </IonToolbar>
        </IonHeader>
        
        <IonContent className="ion-padding">
          {media && (
            <>
              <div style={{ marginBottom: '20px', textAlign: 'center' }}>
                {media.Poster !== 'N/A' ? (
                  <img 
                    src={media.Poster} 
                    alt={media.Title}
                    style={{ 
                      maxHeight: '200px', 
                      borderRadius: '10px', 
                      boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                      margin: '0 auto',
                      display: 'block'
                    }}
                  />
                ) : (
                  <div 
                    style={{ 
                      width: '150px', 
                      height: '200px', 
                      background: 'linear-gradient(135deg, #f5f7fa, #e8eaed)', 
                      display: 'flex', 
                      justifyContent: 'center', 
                      alignItems: 'center',
                      color: '#666666',
                      borderRadius: '10px',
                      margin: '0 auto'
                    }}
                  >
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '42px', marginBottom: '10px' }}>🎬</div>
                      <div>Sense imatge</div>
                    </div>
                  </div>
                )}
              </div>
              
              <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>{media.Title}</h2>
              
              <div className="rating-container ion-padding">
                <IonLabel style={{ fontWeight: 'bold', fontSize: '18px', display: 'block', marginBottom: '10px' }}>
                  La teva valoració
                </IonLabel>
                <div className="rating-stars">
                  <IonRange
                    min={0}
                    max={10}
                    step={0.5}
                    value={userRating}
                    onIonChange={(e) => setUserRating(e.detail.value)}
                    style={{ padding: '0 10px' }}
                  >
                    <IonIcon slot="start" icon={starOutline} style={{ color: '#f59e0b' }} />
                    <IonIcon slot="end" icon={starOutline} style={{ color: '#f59e0b' }} />
                  </IonRange>
                  <div className="ion-text-center">
                    <strong style={{ fontSize: '24px', color: '#f59e0b' }}>{userRating}</strong>
                    <span style={{ fontSize: '18px', color: '#666' }}>/10</span>
                  </div>
                </div>
              </div>
              
              <div className="comment-container ion-padding-top">
                <IonLabel style={{ fontWeight: 'bold', fontSize: '18px', display: 'block', marginBottom: '10px' }}>
                  Els teus comentaris
                </IonLabel>
                <IonTextarea
                  value={userComment}
                  onIonChange={(e) => setUserComment(e.detail.value)}
                  placeholder="Escriu els teus comentaris sobre aquesta pel·lícula o sèrie..."
                  rows={5}
                  style={{ 
                    border: '1px solid rgba(0,0,0,0.1)', 
                    borderRadius: '10px', 
                    '--padding-start': '10px',
                    '--padding-end': '10px',
                    '--padding-top': '10px',
                    '--padding-bottom': '10px',
                    margin: '10px 0'
                  }}
                />
              </div>
              
              <IonButton 
                expand="block" 
                onClick={handleSaveReview} 
                color="secondary"
                className="ion-margin-top"
                style={{ 
                  '--border-radius': '10px',
                  height: '48px',
                  fontSize: '16px',
                  margin: '25px 0 15px'
                }}
              >
                Guardar valoració
              </IonButton>
            </>
          )}
        </IonContent>
      </IonModal>
      
      <IonToast
        isOpen={showToast}
        onDidDismiss={() => setShowToast(false)}
        message={toastMessage}
        duration={2000}
        position="bottom"
      />
      
      <IonFooter>
        <IonTabBar slot="bottom">
          <IonTabButton tab="home" routerLink="/home">
            <IonIcon icon={homeOutline} />
            <IonLabel>Inici</IonLabel>
          </IonTabButton>
          
          <IonTabButton tab="search" routerLink="/search">
            <IonIcon icon={searchOutline} />
            <IonLabel>Cercar</IonLabel>
          </IonTabButton>
          
          <IonTabButton tab="favorites" routerLink="/favorites">
            <IonIcon icon={heartOutline} />
            <IonLabel>Els meus</IonLabel>
          </IonTabButton>
        </IonTabBar>
      </IonFooter>
    </IonPage>
  );
};

export default MovieDetails;