import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { 
  IonContent, 
  IonHeader, 
  IonPage, 
  IonTitle, 
  IonToolbar,
  IonSearchbar,
  IonItem,
  IonLabel,
  IonSelect,
  IonSelectOption,
  IonLoading,
  IonToast,
  IonIcon,
  IonFooter,
  IonTabBar,
  IonTabButton,
  IonButtons,
  IonBackButton,
  IonGrid,
  IonRow,
  IonCol,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonSegment, 
  IonSegmentButton,
  IonButton
} from '@ionic/react';
import { searchOutline, heartOutline, homeOutline, filmOutline, tvOutline } from 'ionicons/icons';
import { searchMedia } from '../services/api';

const Search = () => {
  const history = useHistory();
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState('all');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  
  // Funció per fer la cerca
  const doSearch = async () => {
    if (searchTerm.trim() === '') {
      setToastMessage('Si us plau, introdueix un terme de cerca');
      setShowToast(true);
      return;
    }
    
    setLoading(true);
    
    try {
      const results = await searchMedia(searchTerm, searchType);
      
      if (results.Response === 'True') {
        setSearchResults(results.Search);
      } else {
        setSearchResults([]);
        setToastMessage(results.Error || 'No s\'han trobat resultats');
        setShowToast(true);
      }
    } catch (error) {
      console.error('Error en la cerca:', error);
      setToastMessage('Error al realitzar la cerca');
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  // Canvi en el tipus de cerca
  const handleTypeChange = (newType) => {
    setSearchType(newType);
  };

  // Navegació a la pàgina de detalls
  const navigateToDetails = (imdbID) => {
    history.push(`/details/${imdbID}`);
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="primary">
          <IonButtons slot="start">
            <IonBackButton defaultHref="/home" />
          </IonButtons>
          <IonTitle>Cerca</IonTitle>
        </IonToolbar>
      </IonHeader>
      
      <IonContent className="ion-padding">
        <IonSearchbar
          value={searchTerm}
          onIonChange={(e) => setSearchTerm(e.detail.value)}
          placeholder="Cercar pel·lícules o sèries..."
          debounce={300}
        />
        
        {/* Segment per triar el tipus de cerca */}
        <IonSegment value={searchType} onIonChange={e => handleTypeChange(e.detail.value)}>
          <IonSegmentButton value="all">
            <IonLabel>Tot</IonLabel>
          </IonSegmentButton>
          <IonSegmentButton value="movie">
            <IonLabel>Pel·lícules</IonLabel>
          </IonSegmentButton>
          <IonSegmentButton value="series">
            <IonLabel>Sèries</IonLabel>
          </IonSegmentButton>
        </IonSegment>
        
        {/* Botó de cerca */}
        <IonButton 
          expand="block" 
          onClick={doSearch} 
          color="secondary"
          className="ion-margin-top ion-margin-bottom"
          style={{ 
            '--border-radius': '10px',
            height: '44px'
          }}
        >
          <IonIcon slot="start" icon={searchOutline} />
          Cercar
        </IonButton>
        
        {searchResults.length > 0 ? (
          <IonGrid>
            <IonRow>
              {searchResults.map((item) => (
                <IonCol size="6" key={item.imdbID}>
                  <IonCard 
                    onClick={() => navigateToDetails(item.imdbID)}
                    style={{ 
                      borderRadius: '12px', 
                      overflow: 'hidden',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.08)'
                    }}
                  >
                    {item.Poster !== 'N/A' ? (
                      <img 
                        src={item.Poster} 
                        alt={item.Title}
                        style={{ 
                          width: '100%', 
                          height: '200px', 
                          objectFit: 'cover',
                          borderBottom: '1px solid rgba(0,0,0,0.05)'
                        }}
                      />
                    ) : (
                      <div 
                        style={{ 
                          width: '100%', 
                          height: '200px', 
                          background: 'linear-gradient(135deg, #f5f7fa, #e8eaed)', 
                          display: 'flex', 
                          justifyContent: 'center', 
                          alignItems: 'center',
                          color: '#666666',
                          fontSize: '14px'
                        }}
                      >
                        <div style={{ textAlign: 'center', padding: '20px' }}>
                          <div style={{ fontSize: '32px', marginBottom: '10px' }}>🎬</div>
                          <div>Sense imatge</div>
                        </div>
                      </div>
                    )}
                    <IonCardHeader>
                      <IonCardSubtitle style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                        {item.Year}
                        <span 
                          className={`media-type-label ${item.Type === 'movie' ? 'movie-label' : 'series-label'}`}
                        >
                          {item.Type === 'movie' ? 'Pel·lícula' : 'Sèrie'}
                        </span>
                      </IonCardSubtitle>
                      <IonCardTitle style={{ fontSize: '16px', marginTop: '5px' }}>{item.Title}</IonCardTitle>
                    </IonCardHeader>
                  </IonCard>
                </IonCol>
              ))}
            </IonRow>
          </IonGrid>
        ) : (
          searchTerm && !loading && (
            <div className="ion-text-center ion-padding">
              <p>No hi ha resultats per mostrar</p>
            </div>
          )
        )}
      </IonContent>
      
      <IonLoading
        isOpen={loading}
        message={'Cercant...'}
      />
      
      <IonToast
        isOpen={showToast}
        onDidDismiss={() => setShowToast(false)}
        message={toastMessage}
        duration={2000}
        position="bottom"
      />
      
      <IonFooter>
        <IonTabBar slot="bottom">
          <IonTabButton tab="home" href="/home">
            <IonIcon icon={homeOutline} />
            <IonLabel>Inici</IonLabel>
          </IonTabButton>
          
          <IonTabButton tab="search" href="/search">
            <IonIcon icon={searchOutline} />
            <IonLabel>Cercar</IonLabel>
          </IonTabButton>
          
          <IonTabButton tab="favorites" href="/favorites">
            <IonIcon icon={heartOutline} />
            <IonLabel>Els meus</IonLabel>
          </IonTabButton>
        </IonTabBar>
      </IonFooter>
    </IonPage>
  );
};

export default Search;