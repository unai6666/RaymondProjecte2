import React, { useState } from 'react';
import { 
  IonContent, 
  IonHeader, 
  IonPage, 
  IonTitle, 
  IonToolbar,
  IonCard,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonTabBar,
  IonTabButton,
  IonLabel,
  IonFooter,
  IonButtons,
  IonToast
} from '@ionic/react';
import { searchOutline, heartOutline, homeOutline, logOutOutline } from 'ionicons/icons';
import { logoutUser } from '../services/auth';

const Home = () => {
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  
  const handleLogout = async () => {
    try {
      const result = await logoutUser();
      if (result.error) {
        setToastMessage(result.error);
        setShowToast(true);
      }
    } catch (error) {
      setToastMessage('Error al tancar la sessió');
      setShowToast(true);
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle>La Meva Col·lecció</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={handleLogout}>
              <IonIcon slot="icon-only" icon={logOutOutline} />
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonCard>
          <div 
            style={{ 
              width: '100%', 
              height: '200px', 
              background: 'linear-gradient(135deg, #5a67d8, #8b5cf6)', 
              display: 'flex', 
              flexDirection: 'column',
              justifyContent: 'center', 
              alignItems: 'center',
              color: 'white',
              padding: '20px',
              borderRadius: '10px',
              textAlign: 'center'
            }}
          >
            <div style={{ fontSize: '42px', marginBottom: '10px' }}>🎬</div>
            <div style={{ fontSize: '24px', fontWeight: 'bold' }}>CinemaCol·lecció</div>
            <div style={{ fontSize: '14px', opacity: '0.9', marginTop: '5px' }}>La teva col·lecció personal de cinema</div>
          </div>
          <IonCardHeader>
            <IonCardSubtitle>Benvingut!</IonCardSubtitle>
            <IonCardTitle>La teva app de pel·lícules i sèries</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
            Cerca les teves pel·lícules i sèries favorites, guarda-les a la teva col·lecció personal,
            afegeix valoracions i comentaris.
          </IonCardContent>
          <IonButton 
            expand="block" 
            fill="clear"
            routerLink="/search"
          >
            Cercar ara
            <IonIcon slot="end" icon={searchOutline} />
          </IonButton>
        </IonCard>
        
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>La Meva Col·lecció</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
            Accedeix a la teva col·lecció personal de pel·lícules i sèries.
          </IonCardContent>
          <IonButton 
            expand="block" 
            fill="clear" 
            routerLink="/favorites"
          >
            Veure la meva col·lecció
            <IonIcon slot="end" icon={heartOutline} />
          </IonButton>
        </IonCard>
      </IonContent>
      
      <IonToast
        isOpen={showToast}
        onDidDismiss={() => setShowToast(false)}
        message={toastMessage}
        duration={2000}
        position="bottom"
      />
      
      <IonFooter>
        <IonTabBar slot="bottom">
          <IonTabButton tab="home" routerLink="/home" selected>
            <IonIcon icon={homeOutline} />
            <IonLabel>Inici</IonLabel>
          </IonTabButton>
          
          <IonTabButton tab="search" routerLink="/search">
            <IonIcon icon={searchOutline} />
            <IonLabel>Cercar</IonLabel>
          </IonTabButton>
          
          <IonTabButton tab="favorites" routerLink="/favorites">
            <IonIcon icon={heartOutline} />
            <IonLabel>Els meus</IonLabel>
          </IonTabButton>
        </IonTabBar>
      </IonFooter>
    </IonPage>
  );
};

export default Home;