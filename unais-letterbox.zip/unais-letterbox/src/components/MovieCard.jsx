import React from 'react';
import { IonCard, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon } from '@ionic/react';
import { filmOutline, tvOutline } from 'ionicons/icons';

const MovieCard = ({ media, onClick }) => {
  return (
    <IonCard onClick={onClick}>
      <img 
        src={media.Poster !== 'N/A' ? media.Poster : '/assets/no-poster.jpg'} 
        alt={media.Title}
        style={{ width: '100%', height: '200px', objectFit: 'cover' }}
      />
      <IonCardHeader>
        <IonCardSubtitle>
          {media.Year} {' '}
          {media.Type === 'movie' ? (
            <IonIcon icon={filmOutline} />
          ) : (
            <IonIcon icon={tvOutline} />
          )}
        </IonCardSubtitle>
        <IonCardTitle style={{ fontSize: '16px' }}>{media.Title}</IonCardTitle>
      </IonCardHeader>
    </IonCard>
  );
};

export default MovieCard;
