import React from 'react';
import { IonSearchbar, IonItem, IonLabel, IonSelect, IonSelectOption } from '@ionic/react';

const SearchBar = ({ searchTerm, setSearchTerm, searchType, setSearchType, handleSearch }) => {
  return (
    <form onSubmit={handleSearch}>
      <IonSearchbar
        value={searchTerm}
        onIonChange={(e) => setSearchTerm(e.detail.value)}
        placeholder="Buscar películas o series..."
        debounce={300}
      />
      
      <IonItem>
        <IonLabel>Tipo de búsqueda</IonLabel>
        <IonSelect 
          value={searchType} 
          onIonChange={(e) => setSearchType(e.detail.value)}
        >
          <IonSelectOption value="all">Todo</IonSelectOption>
          <IonSelectOption value="movie">Películas</IonSelectOption>
          <IonSelectOption value="series">Series</IonSelectOption>
        </IonSelect>
      </IonItem>
    </form>
  );
};

export default SearchBar;
