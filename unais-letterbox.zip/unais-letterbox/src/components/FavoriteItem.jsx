import React from 'react';
import { 
  IonItemSliding, 
  IonItem, 
  IonThumbnail, 
  IonLabel, 
  IonBadge,
  IonItemOptions,
  IonItemOption,
  IonIcon
} from '@ionic/react';
import { trash, create, star } from 'ionicons/icons';

const FavoriteItem = ({ media, onEdit, onDelete, onClick }) => {
  return (
    <IonItemSliding>
      <IonItem button onClick={onClick}>
        <IonThumbnail slot="start">
          <img 
            src={media.Poster !== 'N/A' ? media.Poster : '/assets/no-poster.jpg'} 
            alt={media.Title}
          />
        </IonThumbnail>
        <IonLabel>
          <h2>{media.Title}</h2>
          <p>{media.Year} • {media.Type}</p>
          {media.userRating > 0 && (
            <IonBadge color="warning">
              <IonIcon icon={star} /> {media.userRating}/10
            </IonBadge>
          )}
        </IonLabel>
      </IonItem>
      
      <IonItemOptions side="end">
        <IonItemOption color="warning" onClick={() => onEdit(media)}>
          <IonIcon slot="icon-only" icon={create} />
        </IonItemOption>
        <IonItemOption color="danger" onClick={() => onDelete(media.imdbID)}>
          <IonIcon slot="icon-only" icon={trash} />
        </IonItemOption>
      </IonItemOptions>
    </IonItemSliding>
  );
};

export default FavoriteItem;
