import { 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword, 
    signOut,
    onAuthStateChanged
  } from "firebase/auth";
  import { auth } from "./firebase";
  import { clearAllLocalFavorites } from "./storage";
  
  // Cerrar sesión y limpiar favoritos locales
  export const logoutUser = async () => {
    try {
      await signOut(auth);
      clearAllLocalFavorites();
      return { error: null };
    } catch (error) {
      return { error: error.message };
    }
  };
  
  // Registrar un usuario nuevo
  export const registerUser = async (email, password) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      return { user: userCredential.user, error: null };
    } catch (error) {
      return { user: null, error: error.message };
    }
  };
  
  // Iniciar sesión
  export const loginUser = async (email, password) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      return { user: userCredential.user, error: null };
    } catch (error) {
      return { user: null, error: error.message };
    }
  };
  
  // Observador del estado de autenticación
  export const subscribeToAuthChanges = (callback) => {
    return onAuthStateChanged(auth, (user) => {
      callback(user);
    });
  };
  
  // Obtener el usuario actual
  export const getCurrentUser = () => {
    return auth.currentUser;
  };
  