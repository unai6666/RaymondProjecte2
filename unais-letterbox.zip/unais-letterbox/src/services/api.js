import axios from 'axios';

const API_KEY = 'fa5184d1';
const BASE_URL = 'http://www.omdbapi.com/';

// Funció per cercar pel·lícules o sèries
export const searchMedia = async (query, type = 'all') => {
  try {
    let searchType = '';
    if (type === 'movie') searchType = '&type=movie';
    if (type === 'series') searchType = '&type=series';
    
    const response = await axios.get(
      `${BASE_URL}?apikey=${API_KEY}&s=${query}${searchType}`
    );
    
    return response.data;
  } catch (error) {
    console.error('Error cercant contingut:', error);
    throw error;
  }
};

// Funció per obtenir detalls d'una pel·lícula o sèrie específica
export const getMediaDetails = async (imdbID) => {
  try {
    const response = await axios.get(
      `${BASE_URL}?apikey=${API_KEY}&i=${imdbID}&plot=full`
    );
    
    return response.data;
  } catch (error) {
    console.error('Error obtenint detalls:', error);
    throw error;
  }
};