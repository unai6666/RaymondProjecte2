import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCzfbr_iTssFaS6s9UBV1f2B2Pd81CFpbI",
  authDomain: "letterbox-d2e69.firebaseapp.com",
  projectId: "letterbox-d2e69",
  storageBucket: "letterbox-d2e69.firebasestorage.app",
  messagingSenderId: "822788853758",
  appId: "1:822788853758:web:ecaca741fa91fc37dc3aaf",
  measurementId: "G-BTS3TSW7HY",
  databaseURL: "https://letterbox-d2e69-default-rtdb.europe-west1.firebasedatabase.app" 
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const database = getDatabase(app);
export default app;