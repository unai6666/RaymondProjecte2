import { ref, set, remove, onValue, update } from "firebase/database";
import { database } from "./firebase";
import { getCurrentUser } from "./auth";

// Clau base per emmagatzemar els favorits a localStorage
const FAVORITES_BASE_KEY = 'favorites_media';

// Obtenir la clau específica per a l'usuari actual
const getFavoritesKey = () => {
  const user = getCurrentUser();
  return user ? `${FAVORITES_BASE_KEY}_${user.uid}` : FAVORITES_BASE_KEY;
};

// Netejar tots els favorits del localStorage
export const clearAllLocalFavorites = () => {
  // Obtenir totes les claus de localStorage
  const keys = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key.startsWith(FAVORITES_BASE_KEY)) {
      keys.push(key);
    }
  }
  
  // Eliminar les claus relacionades amb favorits
  keys.forEach(key => localStorage.removeItem(key));
};

// Obtenir la llista de favorits de localStorage per a l'usuari actual
export const getLocalFavorites = () => {
  const favoritesKey = getFavoritesKey();
  const favorites = localStorage.getItem(favoritesKey);
  return favorites ? JSON.parse(favorites) : [];
};

// Guardar la llista de favorits a localStorage per a l'usuari actual
export const saveLocalFavorites = (favorites) => {
  const favoritesKey = getFavoritesKey();
  localStorage.setItem(favoritesKey, JSON.stringify(favorites));
};

// Afegir un element a favorits
export const addToFavorites = async (mediaItem) => {
  // Guardar a localStorage
  const localFavorites = getLocalFavorites();
  if (!localFavorites.some(item => item.imdbID === mediaItem.imdbID)) {
    localFavorites.push(mediaItem);
    saveLocalFavorites(localFavorites);
  }
  
  // Guardar a Firebase
  const user = getCurrentUser();
  if (user) {
    try {
      await set(ref(database, `/${user.uid}/${mediaItem.imdbID}`), {
        ...mediaItem,
        addedAt: new Date().toISOString(),
        userRating: mediaItem.userRating || 0,
        userComment: mediaItem.userComment || ''
      });
    } catch (error) {
      console.error("Error afegint favorit a Firebase:", error);
    }
  }
};

// Eliminar un element de favorits
export const removeFromFavorites = async (imdbID) => {
  // Eliminar de localStorage
  const localFavorites = getLocalFavorites();
  const updatedFavorites = localFavorites.filter(item => item.imdbID !== imdbID);
  saveLocalFavorites(updatedFavorites);
  
  // Eliminar de Firebase
  const user = getCurrentUser();
  if (user) {
    try {
      await remove(ref(database, `/${user.uid}/${imdbID}`));
    } catch (error) {
      console.error("Error eliminant favorit de Firebase:", error);
    }
  }
};

// Actualitzar un element de favorits (valoració, comentari)
export const updateFavorite = async (imdbID, updates) => {
  // Actualitzar a localStorage
  const localFavorites = getLocalFavorites();
  const index = localFavorites.findIndex(item => item.imdbID === imdbID);
  
  if (index !== -1) {
    localFavorites[index] = {
      ...localFavorites[index],
      ...updates
    };
    saveLocalFavorites(localFavorites);
  }
  
  // Actualitzar a Firebase
  const user = getCurrentUser();
  if (user) {
    try {
      await update(ref(database, `/${user.uid}/${imdbID}`), updates);
    } catch (error) {
      console.error("Error actualitzant favorit a Firebase:", error);
    }
  }
};

// Verificar si un element està a favorits
export const isInFavorites = (imdbID) => {
  const favorites = getLocalFavorites();
  return favorites.some(item => item.imdbID === imdbID);
};

// Subscriure's a canvis a la base de dades de Firebase
export const subscribeFavoritesFromFirebase = (callback) => {
  const user = getCurrentUser();
  if (!user) {
    callback({});
    return () => {};
  }
  
  const favoritesRef = ref(database, `/${user.uid}`);
  const unsubscribe = onValue(favoritesRef, (snapshot) => {
    const data = snapshot.val() || {};
    // Actualitzar també localStorage per mantenir sincronitzat
    const favorites = Object.values(data);
    saveLocalFavorites(favorites);
    callback(data);
  });
  
  return unsubscribe;
};

// Sincronitzar favorits de localStorage a Firebase (útil després d'iniciar sessió)
export const syncFavoritesToFirebase = async () => {
  const user = getCurrentUser();
  if (!user) return;
  
  const localFavorites = getLocalFavorites();
  
  for (const item of localFavorites) {
    await set(ref(database, `/${user.uid}/${item.imdbID}`), {
      ...item,
      updatedAt: new Date().toISOString()
    });
  }
};